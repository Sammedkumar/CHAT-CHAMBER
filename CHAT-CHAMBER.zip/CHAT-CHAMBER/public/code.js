(function(){
    const app = document.querySelector(".app");
    const socket = io();

    let uname;

    // CAPTCHA related code
    function generateCaptcha() {
        const canvas = document.getElementById('captcha');
        const ctx = canvas.getContext('2d');
        const charsArray = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const lengthOtp = 6;
        const captcha = [];
        
        for (let i = 0; i < lengthOtp; i++) {
            const index = Math.floor(Math.random() * charsArray.length);
            captcha.push(charsArray[index]);
        }
        
        const captchaText = captcha.join('');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = "65px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(captchaText, canvas.width / 2, canvas.height / 2);

        return captchaText;
    }

    let currentCaptcha = generateCaptcha();

    document.getElementById('reload-captcha').addEventListener('click', function() {
        currentCaptcha = generateCaptcha();
    });

    app.querySelector(".join-screen #join-user").addEventListener("click", function(){
        let username = app.querySelector(".join-screen #username").value;
        let roomId = app.querySelector(".join-screen #RoomId").value;
        let captchaInput = app.querySelector(".join-screen #captcha-input").value;

        if (username.length == 0){
            alert("Please enter a name");
            return;
        }
        if (roomId !== "100"){
            alert("Please enter the correct Room ID");
            return;
        }
        if (captchaInput !== currentCaptcha){
            alert("Incorrect CAPTCHA. Please try again.");
            currentCaptcha = generateCaptcha();
            return;
        }

        socket.emit("newuser", username, roomId, function(response){
            if (response.success) {
                uname = username;
                app.querySelector(".join-screen").classList.remove("active");
                app.querySelector(".chat-screen").classList.add("active");
            } else {
                alert(response.message);
            }
        });
    });

    app.querySelector(".chat-screen #send-message").addEventListener("click", function(){
        let message = app.querySelector(".chat-screen #message-input").value;
        if (message.length == 0){
            return;
        }
        renderMessage("my", {
            username: uname,
            text: message,
            roomId: "100"
        });
        socket.emit("chat", {
            username: uname,
            text: message,
            roomId: "100"
        });
        app.querySelector(".chat-screen #message-input").value = "";
    });

    app.querySelector(".chat-screen #exit-chat").addEventListener("click", function(){
        socket.emit("exituser", uname, "100");
        window.location.href = window.location.href;
    });

    socket.on("update", function(update){
        renderMessage("update", update);
    });
    socket.on("chat", function(message){
        renderMessage("other", message);
    });

    function renderMessage(type, message){
        let messageContainer = app.querySelector(".chat-screen .messages");
        if (type == "my"){
            let el = document.createElement("div");
            el.setAttribute("class", "message my-message");
            el.innerHTML = `
                <div>
                    <div class="name">You</div>
                    <div class="text">${message.text}</div>
                </div>
            `;
            messageContainer.appendChild(el);
        } else if (type == "other"){
            let el = document.createElement("div");
            el.setAttribute("class", "message other-message");
            el.innerHTML = `
                <div>
                    <div class="name">${message.username}</div>
                    <div class="text">${message.text}</div>
                </div>
            `;
            messageContainer.appendChild(el);
        } else if (type == "update"){
            let el = document.createElement("div");
            el.setAttribute("class", "update");
            el.innerText = message;
            messageContainer.appendChild(el);
        }
        
        // Scroll chat to end
        messageContainer.scrollTop = messageContainer.scrollHeight - messageContainer.clientHeight;
    }
})();
