const express = require("express");
const path = require("path");

const app = express();
const server = require("http").createServer(app);

const io = require("socket.io")(server);

app.use(express.static(path.join(__dirname + "/public")));

const rooms = {};

io.on("connection", function (socket) {
    socket.on("newuser", function (username, roomId, callback) {
        if (!rooms[roomId]) {
            rooms[roomId] = [];
        }

        if (rooms[roomId].length >= 100) {
            callback({ success: false, message: "Room is full" });
            return;
        }

        rooms[roomId].push({ id: socket.id, username: username });
        socket.join(roomId);
        callback({ success: true });
        socket.broadcast.to(roomId).emit("update", username + " joined the conversation");
    });

    socket.on("exituser", function (username, roomId) {
        if (rooms[roomId]) {
            rooms[roomId] = rooms[roomId].filter(user => user.id !== socket.id);
            socket.leave(roomId);
            socket.broadcast.to(roomId).emit("update", username + " left the conversation");
        }
    });

    socket.on("chat", function (message) {
        socket.broadcast.to(message.roomId).emit("chat", message);
    });

    socket.on("disconnect", function () {
        for (let roomId in rooms) {
            rooms[roomId] = rooms[roomId].filter(user => user.id !== socket.id);
        }
    });
});

server.listen(5000, () => {
    console.log("Listening on port 5000");
});
